# Instructions for Codex in VS Code

I have approved the **Concept 1 ribbon E design direction** for Evolve Through AI. The attached brand kit contains a reconstructed vector logo set, not the original AI illustration.

1. Inspect the current website and existing assets. Do not delete or overwrite useful files without review.
2. Copy the supplied `public/brand/` folder into the Next.js app's actual `public/brand/` directory (adjust for monorepo structure).
3. Preview `logo-light.svg`, `logo-dark.svg`, `symbol.svg`, and favicon at real display sizes. Report any visual discrepancies from the approved concept before applying the assets sitewide.
4. Use `logo-light.svg` in light header/footer contexts, `logo-dark.svg` in dark contexts, and `symbol.svg` or square icons for small placements. Add appropriate alt text.
5. Wire favicon and app icons through Next.js metadata or the existing project's equivalent; do not duplicate metadata definitions.
6. Adopt brand colors as design tokens without changing unrelated page layouts or overusing gradients.
7. Update `docs/DESIGN_REQUIREMENTS.md` and any existing brand documentation to record the assets and usage rules.
8. Test desktop/mobile headers, dark/light contrast, small-size rendering, and production build.
9. Do not invent legal trademark clearance, business claims, or new brand text.
10. Report changes and ask for approval before deploying.

Brand name: **Evolve Through AI**. Descriptor: **Technology • Innovation • Solutions**. Tagline: **Learn. Build. Evolve.**
