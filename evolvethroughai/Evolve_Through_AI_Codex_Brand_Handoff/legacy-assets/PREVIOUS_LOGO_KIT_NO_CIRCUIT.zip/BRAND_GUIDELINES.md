# Evolve Through AI — Brand Kit

**Identity:** Evolve Through AI  
**Descriptor:** Technology • Innovation • Solutions  
**Tagline:** Learn. Build. Evolve.

## Status
This is a newly drawn **vector interpretation** of the selected ribbon-E concept, **not an exact vector extraction** of the AI-generated concept board. Review the symbol before final brand approval or trademark filing.

## Palette
- Midnight `#0B1220`
- Electric blue `#2563EB`
- Cyan `#06B6D4`
- Violet `#8B5CF6`
- Off-white `#F8FAFC`
- Cool gray `#E5E7EB`

## Assets
- `public/brand/logo-light.svg` — full wordmark for light backgrounds
- `public/brand/logo-dark.svg` — full wordmark for dark backgrounds
- `public/brand/symbol.svg` — standalone ribbon E
- `public/brand/symbol-white.svg`, `symbol-midnight.svg` — monochrome variants
- `public/brand/icon-light.svg`, `icon-dark.svg` — square avatars
- PNG exports, multi-size icons, `favicon.ico`

## Usage
Use the full horizontal mark in headers and footers. Use the symbol for favicons and social profiles. Avoid stretching, shadows, additional gradients, and displaying the entire concept board as a logo. The descriptor is optional at small sizes; the tagline should be placed separately in marketing content. SVG text uses Inter with Arial fallback; for fully portable outlined wordmarks, convert text to paths in a vector editor after final approval.

## Approval checks
Review the reconstructed shape against the chosen Concept 1 image, inspect at 16/32px, verify readability in dark/light modes, and perform trademark/similarity review before commercial finalization.
